# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.pass_input_type_algorithm import PassInputTypeAlgorithm


class PassThrough(PassInputTypeAlgorithm):
    r"""
    PassThrough - Pass input input data through to the output
    
    Superclass: PassInputTypeAlgorithm
    
    PassThrough simply passes input data to the output. By default,
    the input is shallow-copied (using `vtkdata_object::shallow_copy`). If
    `deep_copy_input` is true, then the input is deep-copied (using
    `vtkdata_object::deep_copy`).
    
    The output type is always the same as the input object type.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPassThrough, obj, update, **traits)
    
    allow_null_input = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _allow_null_input_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAllowNullInput,
                        self.allow_null_input_)

    deep_copy_input = tvtk_base.false_bool_trait(desc=\
        r"""
        Whether or not to deep copy the input. This can be useful if you
        want to create a copy of a data object. You can then disconnect
        this filter's input connections and it will act like a source.
        Defaults to OFF.
        """
    )

    def _deep_copy_input_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDeepCopyInput,
                        self.deep_copy_input_)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    def fill_input_port_information(self, *args):
        """
        fill_input_port_information(self, port:int, info:Information)
            -> int
        C++: int fill_input_port_information(int port, Information *info)
            override;
        Specify the first input port as optional
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FillInputPortInformation, *my_args)
        return ret

    _updateable_traits_ = \
    (('allow_null_input', 'GetAllowNullInput'), ('deep_copy_input',
    'GetDeepCopyInput'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'allow_null_input', 'debug', 'deep_copy_input',
    'global_warning_display', 'release_data_flag', 'abort_output',
    'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PassThrough, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PassThrough properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['allow_null_input', 'deep_copy_input'], [], ['abort_output',
            'object_name']),
            title='Edit PassThrough properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PassThrough properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

