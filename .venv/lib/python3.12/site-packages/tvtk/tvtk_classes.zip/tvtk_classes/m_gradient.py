# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.gradient_filter import GradientFilter


class mGradient(GradientFilter):
    r"""
    vtkmGradient - A general filter for gradient estimation.
    
    Superclass: GradientFilter
    
    Estimates the gradient of a field in a data set.  The gradient
    calculation is dependent on the input dataset type.  The created
    gradient array is of the same type as the array it is calculated from
    (e.g. point data or cell data) as well as data type (e.g. float,
    double). The output array has 3*number of components of the input
    data array.  The ordering for the output tuple will be {du/dx, du/dy,
    du/dz, dv/dx, dv/dy, dv/dz, dw/dx, dw/dy, dw/dz} for an input array
    {u, v, w}.
    
    Also options to additionally compute the divergence, vorticity and Q
    criterion of input vector fields.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkmGradient, obj, update, **traits)
    
    force_vt_km = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _force_vt_km_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetForceVTKm,
                        self.force_vt_km_)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input data object. This method is not recommended for
        use, but lots of old style filters use it.
        """
    )

    _updateable_traits_ = \
    (('force_vt_km', 'GetForceVTKm'), ('compute_divergence',
    'GetComputeDivergence'), ('compute_gradient', 'GetComputeGradient'),
    ('compute_q_criterion', 'GetComputeQCriterion'), ('compute_vorticity',
    'GetComputeVorticity'), ('faster_approximation',
    'GetFasterApproximation'), ('abort_execute', 'GetAbortExecute'),
    ('release_data_flag', 'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('contributing_cell_option', 'GetContributingCellOption'),
    ('divergence_array_name', 'GetDivergenceArrayName'),
    ('q_criterion_array_name', 'GetQCriterionArrayName'),
    ('replacement_value_option', 'GetReplacementValueOption'),
    ('result_array_name', 'GetResultArrayName'), ('vorticity_array_name',
    'GetVorticityArrayName'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'compute_divergence', 'compute_gradient',
    'compute_q_criterion', 'compute_vorticity', 'debug',
    'faster_approximation', 'force_vt_km', 'global_warning_display',
    'release_data_flag', 'abort_output', 'contributing_cell_option',
    'divergence_array_name', 'object_name', 'progress_text',
    'q_criterion_array_name', 'replacement_value_option',
    'result_array_name', 'vorticity_array_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(mGradient, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit mGradient properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['compute_divergence', 'compute_gradient',
            'compute_q_criterion', 'compute_vorticity', 'faster_approximation',
            'force_vt_km'], [], ['abort_output', 'contributing_cell_option',
            'divergence_array_name', 'object_name', 'q_criterion_array_name',
            'replacement_value_option', 'result_array_name',
            'vorticity_array_name']),
            title='Edit mGradient properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit mGradient properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

