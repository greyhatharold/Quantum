# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.mapper import Mapper


class PolyDataMapper(Mapper):
    r"""
    PolyDataMapper - map PolyData to graphics primitives
    
    Superclass: Mapper
    
    PolyDataMapper is a class that maps polygonal data (i.e.,
    PolyData) to graphics primitives. PolyDataMapper serves as a
    superclass for device-specific poly data mappers, that actually do
    the mapping to the rendering/graphics hardware/software.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPolyDataMapper, obj, update, **traits)
    
    pause_shift_scale = tvtk_base.false_bool_trait(desc=\
        r"""
        Pause per-render updates to VBO shift+scale parameters.
        
        For large datasets, re-uploading the VBO during user interaction
        can cause stutters in the framerate. Interactors can use this
        method to force update_camera_shift_scale to return immediately
        (without changes) while users are zooming/rotating/etc. and then
        re-enable shift-scale just before a still render.
        
        This setting has no effect unless the shift-scale method is set
        to NEAR_PLANE_SHIFT_SCALE or FOCAL_POINT_SHIFT_SCALE.
        
        Changing this setting does **not** mark the mapper as modified as
        that would force a VBO upload – defeating its own purpose.
        """
    )

    def _pause_shift_scale_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPauseShiftScale,
                        self.pause_shift_scale_)

    seamless_u = tvtk_base.false_bool_trait(desc=\
        r"""
        Accessors / Mutators for handling seams on wrapping surfaces.
        Letters U and V stand for texture coordinates (u,v).
        
        ote Implementation taken from the work of Marco Tarini:
        Cylindrical and Toroidal Parameterizations Without Vertex Seams
        Journal of Graphics Tools, 2012, number 3, volume 16, pages
        144-150.
        """
    )

    def _seamless_u_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSeamlessU,
                        self.seamless_u_)

    seamless_v = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _seamless_v_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSeamlessV,
                        self.seamless_v_)

    ghost_level = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set the number of ghost cells to return.
        """
    )

    def _ghost_level_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGhostLevel,
                        self.ghost_level)

    number_of_pieces = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _number_of_pieces_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfPieces,
                        self.number_of_pieces)

    number_of_sub_pieces = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _number_of_sub_pieces_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfSubPieces,
                        self.number_of_sub_pieces)

    piece = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        If you want only a part of the data, specify by setting the
        piece.
        """
    )

    def _piece_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPiece,
                        self.piece)

    vbo_shift_scale_method = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        A convenience method for enabling/disabling
        the VBO's shift+scale transform.
        """
    )

    def _vbo_shift_scale_method_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetVBOShiftScaleMethod,
                        self.vbo_shift_scale_method)

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input as a DataSet.  This method is overridden in the
        specialized mapper classes to return more specific data types.
        """
    )

    def map_data_array_to_multi_texture_attribute(self, *args):
        """
        map_data_array_to_multi_texture_attribute(self, textureName:str,
            dataArrayName:str, fieldAssociation:int, componentno:int=-1)
            -> None
        C++: virtual void map_data_array_to_multi_texture_attribute(
            const char *textureName, const char *dataArrayName,
            int fieldAssociation, int componentno=-1)"""
        ret = self._wrap_call(self._vtk_obj.MapDataArrayToMultiTextureAttribute, *args)
        return ret

    def map_data_array_to_vertex_attribute(self, *args):
        """
        map_data_array_to_vertex_attribute(self, vertexAttributeName:str,
            dataArrayName:str, fieldAssociation:int, componentno:int=-1)
            -> None
        C++: virtual void map_data_array_to_vertex_attribute(
            const char *vertexAttributeName, const char *dataArrayName,
            int fieldAssociation, int componentno=-1)
        Select a data array from the point/cell data and map it to a
        generic vertex attribute. vertexattribute_name is the name of the
        vertex attribute. dataarray_name is the name of the data array.
        fieldAssociation indicates when the data array is a point data
        array or cell data array (vtkdata_object::FIELD_ASSOCIATION_POINTS
        or (vtkdata_object::FIELD_ASSOCIATION_CELLS). componentno
        indicates which component from the data array must be passed as
        the attribute. If -1, then all components are passed. Currently
        only point data is supported.
        """
        ret = self._wrap_call(self._vtk_obj.MapDataArrayToVertexAttribute, *args)
        return ret

    def remove_all_vertex_attribute_mappings(self):
        """
        remove_all_vertex_attribute_mappings(self) -> None
        C++: virtual void remove_all_vertex_attribute_mappings()
        Remove all vertex attributes.
        """
        ret = self._vtk_obj.RemoveAllVertexAttributeMappings()
        return ret
        

    def remove_vertex_attribute_mapping(self, *args):
        """
        remove_vertex_attribute_mapping(self, vertexAttributeName:str)
            -> None
        C++: virtual void remove_vertex_attribute_mapping(
            const char *vertexAttributeName)
        Remove a vertex attribute mapping.
        """
        ret = self._wrap_call(self._vtk_obj.RemoveVertexAttributeMapping, *args)
        return ret

    def render_piece(self, *args):
        """
        render_piece(self, __a:Renderer, __b:Actor) -> None
        C++: virtual void render_piece(Renderer *, Actor *)
        Implemented by sub classes. Actual rendering is done here.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.RenderPiece, *my_args)
        return ret

    def set_input_data(self, *args):
        """
        set_input_data(self, in_:PolyData) -> None
        C++: void set_input_data(PolyData *in)
        Specify the input data to map.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetInputData, *my_args)
        return ret

    _updateable_traits_ = \
    (('pause_shift_scale', 'GetPauseShiftScale'), ('seamless_u',
    'GetSeamlessU'), ('seamless_v', 'GetSeamlessV'),
    ('interpolate_scalars_before_mapping',
    'GetInterpolateScalarsBeforeMapping'), ('scalar_visibility',
    'GetScalarVisibility'), ('static', 'GetStatic'),
    ('use_lookup_table_scalar_range', 'GetUseLookupTableScalarRange'),
    ('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'), ('color_mode',
    'GetColorMode'), ('resolve_coincident_topology',
    'GetResolveCoincidentTopology'), ('scalar_mode', 'GetScalarMode'),
    ('ghost_level', 'GetGhostLevel'), ('number_of_pieces',
    'GetNumberOfPieces'), ('number_of_sub_pieces',
    'GetNumberOfSubPieces'), ('piece', 'GetPiece'),
    ('vbo_shift_scale_method', 'GetVBOShiftScaleMethod'),
    ('array_access_mode', 'GetArrayAccessMode'), ('array_component',
    'GetArrayComponent'), ('array_id', 'GetArrayId'), ('array_name',
    'GetArrayName'), ('field_data_tuple_id', 'GetFieldDataTupleId'),
    ('render_time', 'GetRenderTime'),
    ('resolve_coincident_topology_polygon_offset_faces',
    'GetResolveCoincidentTopologyPolygonOffsetFaces'),
    ('resolve_coincident_topology_z_shift',
    'GetResolveCoincidentTopologyZShift'), ('scalar_range',
    'GetScalarRange'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'interpolate_scalars_before_mapping', 'pause_shift_scale',
    'release_data_flag', 'scalar_visibility', 'seamless_u', 'seamless_v',
    'static', 'use_lookup_table_scalar_range', 'color_mode',
    'resolve_coincident_topology', 'scalar_mode', 'abort_output',
    'array_access_mode', 'array_component', 'array_id', 'array_name',
    'field_data_tuple_id', 'ghost_level', 'number_of_pieces',
    'number_of_sub_pieces', 'object_name', 'piece', 'progress_text',
    'render_time', 'resolve_coincident_topology_polygon_offset_faces',
    'resolve_coincident_topology_z_shift', 'scalar_range',
    'vbo_shift_scale_method'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PolyDataMapper, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PolyDataMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['interpolate_scalars_before_mapping', 'pause_shift_scale',
            'scalar_visibility', 'seamless_u', 'seamless_v', 'static',
            'use_lookup_table_scalar_range'], ['color_mode',
            'resolve_coincident_topology', 'scalar_mode'], ['abort_output',
            'array_access_mode', 'array_component', 'array_id', 'array_name',
            'field_data_tuple_id', 'ghost_level', 'number_of_pieces',
            'number_of_sub_pieces', 'object_name', 'piece', 'render_time',
            'resolve_coincident_topology_polygon_offset_faces',
            'resolve_coincident_topology_z_shift', 'scalar_range',
            'vbo_shift_scale_method']),
            title='Edit PolyDataMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PolyDataMapper properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

