# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.context_item import ContextItem


class Plot(ContextItem):
    r"""
    Plot - Abstract class for 2D plots.
    
    Superclass: ContextItem
    
    The base class for all plot types used in Chart derived charts.
    
    @sa
    PlotPoints PlotLine PlotBar Chart ChartXY
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPlot, obj, update, **traits)
    
    legend_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Set whether the plot renders an entry in the legend. Default is
        true. Plot::PaintLegend will get called to render the legend
        marker on when this is true.
        """
    )

    def _legend_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLegendVisibility,
                        self.legend_visibility_)

    selectable = tvtk_base.true_bool_trait(desc=\
        r"""
        Set whether the plot can be selected. True by default. If not,
        then set_selection(), select_points() or select_points_in_polygon()
        won't have any effect.
        \sa set_selection(), select_points(), select_points_in_polygon()
        """
    )

    def _selectable_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSelectable,
                        self.selectable_)

    def _get_brush(self):
        return wrap_vtk(self._vtk_obj.GetBrush())
    def _set_brush(self, arg):
        old_val = self._get_brush()
        self._wrap_call(self._vtk_obj.SetBrush,
                        deref_vtk(arg))
        self.trait_property_changed('brush', old_val, arg)
    brush = traits.Property(_get_brush, _set_brush, desc=\
        r"""
        
        """
    )

    def get_color(self, *args):
        """
        get_color(self, rgb:[int, int, int]) -> None
        C++: void get_color(unsigned char rgb[3])
        get_color(self, rgb:[float, float, float]) -> None
        C++: virtual void get_color(double rgb[3])
        Get the plot color as integer rgb values (comprised between 0 and
        255)
        """
        ret = self._wrap_call(self._vtk_obj.GetColor, *args)
        return ret

    def set_color(self, *args):
        """
        set_color(self, r:int, g:int, b:int, a:int) -> None
        C++: virtual void set_color(unsigned char r, unsigned char g,
            unsigned char b, unsigned char a)
        set_color(self, r:float, g:float, b:float) -> None
        C++: virtual void set_color(double r, double g, double b)
        Set the plot color with integer values (comprised between 0 and
        255)
        """
        ret = self._wrap_call(self._vtk_obj.SetColor, *args)
        return ret

    def get_color_f(self, *args):
        """
        get_color_f(self, rgb:[float, float, float]) -> None
        C++: virtual void get_color_f(double rgb[3])
        Get the plot color as floating rgb values (comprised between 0.0
        and 1.0)
        """
        ret = self._wrap_call(self._vtk_obj.GetColorF, *args)
        return ret

    def set_color_f(self, *args):
        """
        set_color_f(self, r:float, g:float, b:float, a:float) -> None
        C++: virtual void set_color_f(double r, double g, double b,
            double a)
        set_color_f(self, r:float, g:float, b:float) -> None
        C++: virtual void set_color_f(double r, double g, double b)
        Set the plot color with floating values (comprised between 0.0
        and 1.0)
        """
        ret = self._wrap_call(self._vtk_obj.SetColorF, *args)
        return ret

    def _get_indexed_labels(self):
        return wrap_vtk(self._vtk_obj.GetIndexedLabels())
    def _set_indexed_labels(self, arg):
        old_val = self._get_indexed_labels()
        my_arg = deref_array([arg], [['vtkStringArray']])
        self._wrap_call(self._vtk_obj.SetIndexedLabels,
                        my_arg[0])
        self.trait_property_changed('indexed_labels', old_val, arg)
    indexed_labels = traits.Property(_get_indexed_labels, _set_indexed_labels, desc=\
        r"""
        Get the indexed labels array.
        """
    )

    def _get_input_connection(self):
        if self._vtk_obj.GetTotalNumberOfInputConnections():
            return wrap_vtk(self._vtk_obj.GetInputConnection(0, 0))
        else:
            return None
    
    def _set_input_connection(self, obj):
        old_val = self._get_input_connection()
        self._wrap_call(self._vtk_obj.SetInputConnection, deref_vtk(obj))
        self.trait_property_changed('input_connection', old_val, obj)
    input_connection = traits.Property(_get_input_connection,
                                       _set_input_connection,
                                       desc="The first input connection for this object, i.e. the result of `get_input_connection(0, 0)`.")
    
    def get_input_connection(self):
        """
        get_input_connection(self) -> AlgorithmOutput
        C++: AlgorithmOutput *get_input_connection()
        Get the input connection used by the plot.
        """
        ret = wrap_vtk(self._vtk_obj.GetInputConnection())
        return ret
        

    def set_input_connection(self, *args):
        """
        set_input_connection(self, input:AlgorithmOutput) -> None
        C++: virtual void set_input_connection(AlgorithmOutput *input)
        This is a convenience function to set the input connection for
        the plot.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetInputConnection, *my_args)
        return ret

    label = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        Set the label of this plot.
        """
    )

    def _label_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLabel,
                        self.label)

    def _get_labels(self):
        return wrap_vtk(self._vtk_obj.GetLabels())
    def _set_labels(self, arg):
        old_val = self._get_labels()
        my_arg = deref_array([arg], [['vtkStringArray']])
        self._wrap_call(self._vtk_obj.SetLabels,
                        my_arg[0])
        self.trait_property_changed('labels', old_val, arg)
    labels = traits.Property(_get_labels, _set_labels, desc=\
        r"""
        Get the plot labels. If this array has a length greater than 1
        the index refers to the stacked objects in the plot. See
        PlotBar for example.
        """
    )

    def _get_pen(self):
        return wrap_vtk(self._vtk_obj.GetPen())
    def _set_pen(self, arg):
        old_val = self._get_pen()
        self._wrap_call(self._vtk_obj.SetPen,
                        deref_vtk(arg))
        self.trait_property_changed('pen', old_val, arg)
    pen = traits.Property(_get_pen, _set_pen, desc=\
        r"""
        
        """
    )

    def get_property(self, *args):
        """
        get_property(self, property:str) -> Variant
        C++: virtual Variant get_property(const StdString &property)"""
        ret = self._wrap_call(self._vtk_obj.GetProperty, *args)
        return wrap_vtk(ret)

    def set_property(self, *args):
        """
        set_property(self, property:str, var:Variant) -> None
        C++: virtual void set_property(const StdString &property,
            const Variant &var)
        A General setter/getter that should be overridden. It can
        silently drop options, case is important
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetProperty, *my_args)
        return ret

    def _get_selection(self):
        return wrap_vtk(self._vtk_obj.GetSelection())
    def _set_selection(self, arg):
        old_val = self._get_selection()
        my_arg = deref_array([arg], [['vtkIdTypeArray']])
        self._wrap_call(self._vtk_obj.SetSelection,
                        my_arg[0])
        self.trait_property_changed('selection', old_val, arg)
    selection = traits.Property(_get_selection, _set_selection, desc=\
        r"""
        
        """
    )

    def _get_selection_brush(self):
        return wrap_vtk(self._vtk_obj.GetSelectionBrush())
    def _set_selection_brush(self, arg):
        old_val = self._get_selection_brush()
        self._wrap_call(self._vtk_obj.SetSelectionBrush,
                        deref_vtk(arg))
        self.trait_property_changed('selection_brush', old_val, arg)
    selection_brush = traits.Property(_get_selection_brush, _set_selection_brush, desc=\
        r"""
        
        """
    )

    def _get_selection_pen(self):
        return wrap_vtk(self._vtk_obj.GetSelectionPen())
    def _set_selection_pen(self, arg):
        old_val = self._get_selection_pen()
        self._wrap_call(self._vtk_obj.SetSelectionPen,
                        deref_vtk(arg))
        self.trait_property_changed('selection_pen', old_val, arg)
    selection_pen = traits.Property(_get_selection_pen, _set_selection_pen, desc=\
        r"""
        
        """
    )

    tooltip_label_format = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        Sets/gets a printf-style string to build custom tooltip labels
        from. An empty string generates the default tooltip labels. The
        following case-sensitive format tags (without quotes) are
        recognized: '%x' The X value of the plot element '%y' The Y value
        of the plot element '%i' The indexed_labels entry for the plot
        element '%l' The value of the plot's get_label() function '%s'
        (vtkplot_bar only) The Labels entry for the bar segment Any other
        characters or unrecognized format tags are printed in the tooltip
        label verbatim.
        """
    )

    def _tooltip_label_format_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTooltipLabelFormat,
                        self.tooltip_label_format)

    tooltip_notation = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Sets/gets the tooltip notation style.
        """
    )

    def _tooltip_notation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTooltipNotation,
                        self.tooltip_notation)

    tooltip_precision = traits.Int(6, enter_set=True, auto_set=False, desc=\
        r"""
        Sets/gets the tooltip precision.
        """
    )

    def _tooltip_precision_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTooltipPrecision,
                        self.tooltip_precision)

    use_index_for_x_series = traits.Bool(False, enter_set=True, auto_set=False, desc=\
        r"""
        Use the Y array index for the X value. If true any X column
        setting will be ignored, and the X values will simply be the
        index of the Y column.
        """
    )

    def _use_index_for_x_series_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUseIndexForXSeries,
                        self.use_index_for_x_series)

    width = traits.Float(2.0, enter_set=True, auto_set=False, desc=\
        r"""
        @
        
        Set the width of the line.
        """
    )

    def _width_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetWidth,
                        self.width)

    def _get_x_axis(self):
        return wrap_vtk(self._vtk_obj.GetXAxis())
    def _set_x_axis(self, arg):
        old_val = self._get_x_axis()
        self._wrap_call(self._vtk_obj.SetXAxis,
                        deref_vtk(arg))
        self.trait_property_changed('x_axis', old_val, arg)
    x_axis = traits.Property(_get_x_axis, _set_x_axis, desc=\
        r"""
        Get/set the X axis associated with this plot.
        """
    )

    def _get_y_axis(self):
        return wrap_vtk(self._vtk_obj.GetYAxis())
    def _set_y_axis(self, arg):
        old_val = self._get_y_axis()
        self._wrap_call(self._vtk_obj.SetYAxis,
                        deref_vtk(arg))
        self.trait_property_changed('y_axis', old_val, arg)
    y_axis = traits.Property(_get_y_axis, _set_y_axis, desc=\
        r"""
        Get/set the Y axis associated with this plot.
        """
    )

    def get_bounds(self, *args):
        """
        get_bounds(self, bounds:[float, float, float, float]) -> None
        C++: virtual void get_bounds(double bounds[4])
        Get the bounds for this plot as (Xmin, Xmax, Ymin, Ymax).
        
        * See get_unscaled_input_bounds for more information.
        """
        ret = self._wrap_call(self._vtk_obj.GetBounds, *args)
        return ret

    def _get_data(self):
        return wrap_vtk(self._vtk_obj.GetData())
    data = traits.Property(_get_data, desc=\
        r"""
        Get the data object that the plot will draw.
        """
    )

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input table used by the plot.
        """
    )

    def _get_number_of_labels(self):
        return self._vtk_obj.GetNumberOfLabels()
    number_of_labels = traits.Property(_get_number_of_labels, desc=\
        r"""
        Get the number of labels associated with this plot.
        """
    )

    def get_tooltip_label(self, *args):
        """
        get_tooltip_label(self, plotPos:Vector2d, seriesIndex:int,
            segmentIndex:int) -> str
        C++: virtual StdString get_tooltip_label(
            const Vector2d &plotPos, IdType seriesIndex,
            IdType segmentIndex)
        Generate and return the tooltip label string for this plot The
        segmentIndex parameter is ignored, except for PlotBar
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.GetTooltipLabel, *my_args)
        return ret

    def get_unscaled_input_bounds(self, *args):
        """
        get_unscaled_input_bounds(self, bounds:[float, float, float, float])
            -> None
        C++: virtual void get_unscaled_input_bounds(double bounds[4])
        Provide un-log-scaled bounds for the plot inputs.
        
        * This function is analogous to get_bounds() with 2 exceptions:
        * 1. It will never return log-scaled bounds even when the
        * x- and/or y-axes are log-scaled.
        * 2. It will always return the bounds along the *input* axes
        * rather than the output chart coordinates. Thus get_x_axis()
        * returns the axis associated with the first 2 bounds entries
        * and get_y_axis() returns the axis associated with the next 2
        * bounds entries.
        
        * For example, PlotBar's get_bounds() method
        * will swap axis bounds when its orientation is vertical while
        * its get_unscaled_input_bounds() will not swap axis bounds.
        
        * This method is provided so user interfaces can determine
        * whether or not to allow log-scaling of a particular Axis.
        
        * Subclasses of Plot are responsible for implementing this
        * function to transform input plot data.
        
        * The returned bounds are stored as (Xmin, Xmax, Ymin, Ymax).
        """
        ret = self._wrap_call(self._vtk_obj.GetUnscaledInputBounds, *args)
        return ret

    def clamp_pos(self, *args):
        """
        clamp_pos(pos:[float, float], bounds:[float, float, float, float])
            -> bool
        C++: static bool clamp_pos(double pos[2], double bounds[4])
        clamp_pos(self, pos:[float, float]) -> bool
        C++: virtual bool clamp_pos(double pos[2])
        Clamp the given 2D pos into the provided bounds Return true if
        the pos has been clamped, false otherwise.
        """
        ret = self._wrap_call(self._vtk_obj.ClampPos, *args)
        return ret

    def filter_selected_points(self, *args):
        """
        filter_selected_points(points:DataArray,
            selectedPoints:DataArray, selectedIds:IdTypeArray)
            -> None
        C++: static void filter_selected_points(DataArray *points,
            DataArray *selectedPoints, IdTypeArray *selectedIds)
        Utility function that fills up `selectedPoints` with tuples from
        `points`. Indices from `selectedIds` are used to index into
        `points`.
        """
        my_args = deref_array(args, [('vtkDataArray', 'vtkDataArray', 'vtkIdTypeArray')])
        ret = self._wrap_call(self._vtk_obj.FilterSelectedPoints, *my_args)
        return ret

    def paint_legend(self, *args):
        """
        paint_legend(self, painter:Context2D, rect:Rectf,
            legendIndex:int) -> bool
        C++: virtual bool paint_legend(Context2D *painter,
            const Rectf &rect, int legendIndex)
        Paint legend event for the plot, called whenever the legend needs
        the plot items symbol/mark/line drawn. A rect is supplied with
        the lower left corner of the rect (elements 0 and 1) and with
        width x height (elements 2 and 3). The plot can choose how to
        fill the space supplied. The index is used by Plots that return
        more than one label.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.PaintLegend, *my_args)
        return ret

    def select_points(self, *args):
        """
        select_points(self, min:Vector2f, max:Vector2f) -> bool
        C++: virtual bool select_points(const Vector2f &min,
            const Vector2f &max)
        Select all points in the specified rectangle.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SelectPoints, *my_args)
        return ret

    def select_points_in_polygon(self, *args):
        """
        select_points_in_polygon(self, polygon:ContextPolygon) -> bool
        C++: virtual bool select_points_in_polygon(
            const ContextPolygon &polygon)
        Select all points in the specified polygon.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SelectPointsInPolygon, *my_args)
        return ret

    def set_input_array(self, *args):
        """
        set_input_array(self, index:int, name:str) -> None
        C++: virtual void set_input_array(int index,
            const StdString &name)
        Convenience function to set the input arrays. For most plots
        index 0 is the x axis, and index 1 is the y axis. The name is the
        name of the column in the Table.
        """
        ret = self._wrap_call(self._vtk_obj.SetInputArray, *args)
        return ret

    def set_input_data(self, *args):
        """
        set_input_data(self, table:Table) -> None
        C++: virtual void set_input_data(Table *table)
        set_input_data(self, table:Table, xColumn:str, yColumn:str)
            -> None
        C++: virtual void set_input_data(Table *table,
            const StdString &xColumn, const StdString &yColumn)
        set_input_data(self, table:Table, xColumn:int, yColumn:int)
            -> None
        C++: void set_input_data(Table *table, IdType xColumn,
            IdType yColumn)
        This is a convenience function to set the input table and the x,
        y column for the plot.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetInputData, *my_args)
        return ret

    def update_cache(self):
        """
        update_cache(self) -> bool
        C++: virtual bool update_cache()
        Update the internal cache. Returns true if cache was successfully
        updated. Default does nothing. This method is called by Update()
        when either the plot's data has changed or cache_requires_update()
        returns true. It is not necessary to call this method explicitly.
        """
        ret = self._vtk_obj.UpdateCache()
        return ret
        

    _updateable_traits_ = \
    (('legend_visibility', 'GetLegendVisibility'), ('selectable',
    'GetSelectable'), ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('label', 'GetLabel'),
    ('tooltip_label_format', 'GetTooltipLabelFormat'),
    ('tooltip_notation', 'GetTooltipNotation'), ('tooltip_precision',
    'GetTooltipPrecision'), ('use_index_for_x_series',
    'GetUseIndexForXSeries'), ('width', 'GetWidth'), ('opacity',
    'GetOpacity'), ('interactive', 'GetInteractive'), ('visible',
    'GetVisible'), ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'legend_visibility',
    'selectable', 'interactive', 'label', 'object_name', 'opacity',
    'tooltip_label_format', 'tooltip_notation', 'tooltip_precision',
    'use_index_for_x_series', 'visible', 'width'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Plot, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Plot properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['legend_visibility', 'selectable'], [], ['interactive',
            'label', 'object_name', 'opacity', 'tooltip_label_format',
            'tooltip_notation', 'tooltip_precision', 'use_index_for_x_series',
            'visible', 'width']),
            title='Edit Plot properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Plot properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

